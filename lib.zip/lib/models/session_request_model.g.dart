// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'session_request_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SessionRequestModelImpl _$$SessionRequestModelImplFromJson(
  Map<String, dynamic> json,
) => _$SessionRequestModelImpl(
  id: json['id'] as String?,
  studentId: json['studentId'] as String,
  mohaffezId: json['mohaffezId'] as String,
  studentName: json['studentName'] as String,
  mohaffezName: json['mohaffezName'] as String,
  sessionType: json['sessionType'] as String,
  preferredTimeSlot: json['preferredTimeSlot'] as String,
  status:
      $enumDecodeNullable(_$SessionRequestStatusEnumMap, json['status']) ??
      SessionRequestStatus.pending,
  imamAddressText: json['imamAddressText'] as String?,
  imamAddressLat: (json['imamAddressLat'] as num?)?.toDouble(),
  imamAddressLng: (json['imamAddressLng'] as num?)?.toDouble(),
  mohaffezPhone: json['mohaffezPhone'] as String?,
  slotDate: const TimestampConverter().fromJson(json['slotDate']),
  slotStart: const TimestampConverter().fromJson(json['slotStart']),
  slotEnd: const TimestampConverter().fromJson(json['slotEnd']),
  createdAt: const TimestampConverter().fromJson(json['createdAt']),
);

Map<String, dynamic> _$$SessionRequestModelImplToJson(
  _$SessionRequestModelImpl instance,
) => <String, dynamic>{
  'id': instance.id,
  'studentId': instance.studentId,
  'mohaffezId': instance.mohaffezId,
  'studentName': instance.studentName,
  'mohaffezName': instance.mohaffezName,
  'sessionType': instance.sessionType,
  'preferredTimeSlot': instance.preferredTimeSlot,
  'status': _$SessionRequestStatusEnumMap[instance.status]!,
  'imamAddressText': instance.imamAddressText,
  'imamAddressLat': instance.imamAddressLat,
  'imamAddressLng': instance.imamAddressLng,
  'mohaffezPhone': instance.mohaffezPhone,
  'slotDate': const TimestampConverter().toJson(instance.slotDate),
  'slotStart': const TimestampConverter().toJson(instance.slotStart),
  'slotEnd': const TimestampConverter().toJson(instance.slotEnd),
  'createdAt': const TimestampConverter().toJson(instance.createdAt),
};

const _$SessionRequestStatusEnumMap = {
  SessionRequestStatus.pending: 'pending',
  SessionRequestStatus.accepted: 'accepted',
  SessionRequestStatus.rejected: 'rejected',
};
