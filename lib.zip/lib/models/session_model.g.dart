// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'session_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SessionModelImpl _$$SessionModelImplFromJson(Map<String, dynamic> json) =>
    _$SessionModelImpl(
      id: json['id'] as String?,
      mohaffezId: json['mohaffezId'] as String,
      studentId: json['studentId'] as String,
      mohaffezName: json['mohaffezName'] as String,
      studentName: json['studentName'] as String,
      sessionType: json['sessionType'] as String,
      location: json['location'] as String,
      mohaffezPhone: json['mohaffezPhone'] as String?,
      imamAddressLat: (json['imamAddressLat'] as num?)?.toDouble(),
      imamAddressLng: (json['imamAddressLng'] as num?)?.toDouble(),
      preferredTimeSlot: json['preferredTimeSlot'] as String?,
      juzCount: (json['juzCount'] as num?)?.toInt() ?? 1,
      hifzAssignment: json['hifzAssignment'] as String?,
      murajaAssignment: json['murajaAssignment'] as String?,
      sessionRating: (json['sessionRating'] as num?)?.toInt() ?? 0,
      sessionNotes: json['sessionNotes'] as String?,
      sessionDate: const TimestampConverter().fromJson(json['sessionDate']),
      slotStart: const TimestampConverter().fromJson(json['slotStart']),
      slotEnd: const TimestampConverter().fromJson(json['slotEnd']),
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

Map<String, dynamic> _$$SessionModelImplToJson(_$SessionModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'mohaffezId': instance.mohaffezId,
      'studentId': instance.studentId,
      'mohaffezName': instance.mohaffezName,
      'studentName': instance.studentName,
      'sessionType': instance.sessionType,
      'location': instance.location,
      'mohaffezPhone': instance.mohaffezPhone,
      'imamAddressLat': instance.imamAddressLat,
      'imamAddressLng': instance.imamAddressLng,
      'preferredTimeSlot': instance.preferredTimeSlot,
      'juzCount': instance.juzCount,
      'hifzAssignment': instance.hifzAssignment,
      'murajaAssignment': instance.murajaAssignment,
      'sessionRating': instance.sessionRating,
      'sessionNotes': instance.sessionNotes,
      'sessionDate': const TimestampConverter().toJson(instance.sessionDate),
      'slotStart': const TimestampConverter().toJson(instance.slotStart),
      'slotEnd': const TimestampConverter().toJson(instance.slotEnd),
      'createdAt': const TimestampConverter().toJson(instance.createdAt),
    };
