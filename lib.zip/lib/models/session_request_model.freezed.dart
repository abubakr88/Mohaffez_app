// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'session_request_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
  'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models',
);

SessionRequestModel _$SessionRequestModelFromJson(Map<String, dynamic> json) {
  return _SessionRequestModel.fromJson(json);
}

/// @nodoc
mixin _$SessionRequestModel {
  String? get id => throw _privateConstructorUsedError;
  String get studentId => throw _privateConstructorUsedError;
  String get mohaffezId => throw _privateConstructorUsedError;
  String get studentName => throw _privateConstructorUsedError;
  String get mohaffezName => throw _privateConstructorUsedError;
  String get sessionType => throw _privateConstructorUsedError;
  String get preferredTimeSlot => throw _privateConstructorUsedError;
  SessionRequestStatus get status => throw _privateConstructorUsedError;
  String? get imamAddressText => throw _privateConstructorUsedError;
  double? get imamAddressLat => throw _privateConstructorUsedError;
  double? get imamAddressLng => throw _privateConstructorUsedError;
  String? get mohaffezPhone => throw _privateConstructorUsedError;
  @TimestampConverter()
  DateTime? get slotDate => throw _privateConstructorUsedError;
  @TimestampConverter()
  DateTime? get slotStart => throw _privateConstructorUsedError;
  @TimestampConverter()
  DateTime? get slotEnd => throw _privateConstructorUsedError;
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  /// Serializes this SessionRequestModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of SessionRequestModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $SessionRequestModelCopyWith<SessionRequestModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SessionRequestModelCopyWith<$Res> {
  factory $SessionRequestModelCopyWith(
    SessionRequestModel value,
    $Res Function(SessionRequestModel) then,
  ) = _$SessionRequestModelCopyWithImpl<$Res, SessionRequestModel>;
  @useResult
  $Res call({
    String? id,
    String studentId,
    String mohaffezId,
    String studentName,
    String mohaffezName,
    String sessionType,
    String preferredTimeSlot,
    SessionRequestStatus status,
    String? imamAddressText,
    double? imamAddressLat,
    double? imamAddressLng,
    String? mohaffezPhone,
    @TimestampConverter() DateTime? slotDate,
    @TimestampConverter() DateTime? slotStart,
    @TimestampConverter() DateTime? slotEnd,
    @TimestampConverter() DateTime? createdAt,
  });
}

/// @nodoc
class _$SessionRequestModelCopyWithImpl<$Res, $Val extends SessionRequestModel>
    implements $SessionRequestModelCopyWith<$Res> {
  _$SessionRequestModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of SessionRequestModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? studentId = null,
    Object? mohaffezId = null,
    Object? studentName = null,
    Object? mohaffezName = null,
    Object? sessionType = null,
    Object? preferredTimeSlot = null,
    Object? status = null,
    Object? imamAddressText = freezed,
    Object? imamAddressLat = freezed,
    Object? imamAddressLng = freezed,
    Object? mohaffezPhone = freezed,
    Object? slotDate = freezed,
    Object? slotStart = freezed,
    Object? slotEnd = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(
      _value.copyWith(
            id: freezed == id
                ? _value.id
                : id // ignore: cast_nullable_to_non_nullable
                      as String?,
            studentId: null == studentId
                ? _value.studentId
                : studentId // ignore: cast_nullable_to_non_nullable
                      as String,
            mohaffezId: null == mohaffezId
                ? _value.mohaffezId
                : mohaffezId // ignore: cast_nullable_to_non_nullable
                      as String,
            studentName: null == studentName
                ? _value.studentName
                : studentName // ignore: cast_nullable_to_non_nullable
                      as String,
            mohaffezName: null == mohaffezName
                ? _value.mohaffezName
                : mohaffezName // ignore: cast_nullable_to_non_nullable
                      as String,
            sessionType: null == sessionType
                ? _value.sessionType
                : sessionType // ignore: cast_nullable_to_non_nullable
                      as String,
            preferredTimeSlot: null == preferredTimeSlot
                ? _value.preferredTimeSlot
                : preferredTimeSlot // ignore: cast_nullable_to_non_nullable
                      as String,
            status: null == status
                ? _value.status
                : status // ignore: cast_nullable_to_non_nullable
                      as SessionRequestStatus,
            imamAddressText: freezed == imamAddressText
                ? _value.imamAddressText
                : imamAddressText // ignore: cast_nullable_to_non_nullable
                      as String?,
            imamAddressLat: freezed == imamAddressLat
                ? _value.imamAddressLat
                : imamAddressLat // ignore: cast_nullable_to_non_nullable
                      as double?,
            imamAddressLng: freezed == imamAddressLng
                ? _value.imamAddressLng
                : imamAddressLng // ignore: cast_nullable_to_non_nullable
                      as double?,
            mohaffezPhone: freezed == mohaffezPhone
                ? _value.mohaffezPhone
                : mohaffezPhone // ignore: cast_nullable_to_non_nullable
                      as String?,
            slotDate: freezed == slotDate
                ? _value.slotDate
                : slotDate // ignore: cast_nullable_to_non_nullable
                      as DateTime?,
            slotStart: freezed == slotStart
                ? _value.slotStart
                : slotStart // ignore: cast_nullable_to_non_nullable
                      as DateTime?,
            slotEnd: freezed == slotEnd
                ? _value.slotEnd
                : slotEnd // ignore: cast_nullable_to_non_nullable
                      as DateTime?,
            createdAt: freezed == createdAt
                ? _value.createdAt
                : createdAt // ignore: cast_nullable_to_non_nullable
                      as DateTime?,
          )
          as $Val,
    );
  }
}

/// @nodoc
abstract class _$$SessionRequestModelImplCopyWith<$Res>
    implements $SessionRequestModelCopyWith<$Res> {
  factory _$$SessionRequestModelImplCopyWith(
    _$SessionRequestModelImpl value,
    $Res Function(_$SessionRequestModelImpl) then,
  ) = __$$SessionRequestModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({
    String? id,
    String studentId,
    String mohaffezId,
    String studentName,
    String mohaffezName,
    String sessionType,
    String preferredTimeSlot,
    SessionRequestStatus status,
    String? imamAddressText,
    double? imamAddressLat,
    double? imamAddressLng,
    String? mohaffezPhone,
    @TimestampConverter() DateTime? slotDate,
    @TimestampConverter() DateTime? slotStart,
    @TimestampConverter() DateTime? slotEnd,
    @TimestampConverter() DateTime? createdAt,
  });
}

/// @nodoc
class __$$SessionRequestModelImplCopyWithImpl<$Res>
    extends _$SessionRequestModelCopyWithImpl<$Res, _$SessionRequestModelImpl>
    implements _$$SessionRequestModelImplCopyWith<$Res> {
  __$$SessionRequestModelImplCopyWithImpl(
    _$SessionRequestModelImpl _value,
    $Res Function(_$SessionRequestModelImpl) _then,
  ) : super(_value, _then);

  /// Create a copy of SessionRequestModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? studentId = null,
    Object? mohaffezId = null,
    Object? studentName = null,
    Object? mohaffezName = null,
    Object? sessionType = null,
    Object? preferredTimeSlot = null,
    Object? status = null,
    Object? imamAddressText = freezed,
    Object? imamAddressLat = freezed,
    Object? imamAddressLng = freezed,
    Object? mohaffezPhone = freezed,
    Object? slotDate = freezed,
    Object? slotStart = freezed,
    Object? slotEnd = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(
      _$SessionRequestModelImpl(
        id: freezed == id
            ? _value.id
            : id // ignore: cast_nullable_to_non_nullable
                  as String?,
        studentId: null == studentId
            ? _value.studentId
            : studentId // ignore: cast_nullable_to_non_nullable
                  as String,
        mohaffezId: null == mohaffezId
            ? _value.mohaffezId
            : mohaffezId // ignore: cast_nullable_to_non_nullable
                  as String,
        studentName: null == studentName
            ? _value.studentName
            : studentName // ignore: cast_nullable_to_non_nullable
                  as String,
        mohaffezName: null == mohaffezName
            ? _value.mohaffezName
            : mohaffezName // ignore: cast_nullable_to_non_nullable
                  as String,
        sessionType: null == sessionType
            ? _value.sessionType
            : sessionType // ignore: cast_nullable_to_non_nullable
                  as String,
        preferredTimeSlot: null == preferredTimeSlot
            ? _value.preferredTimeSlot
            : preferredTimeSlot // ignore: cast_nullable_to_non_nullable
                  as String,
        status: null == status
            ? _value.status
            : status // ignore: cast_nullable_to_non_nullable
                  as SessionRequestStatus,
        imamAddressText: freezed == imamAddressText
            ? _value.imamAddressText
            : imamAddressText // ignore: cast_nullable_to_non_nullable
                  as String?,
        imamAddressLat: freezed == imamAddressLat
            ? _value.imamAddressLat
            : imamAddressLat // ignore: cast_nullable_to_non_nullable
                  as double?,
        imamAddressLng: freezed == imamAddressLng
            ? _value.imamAddressLng
            : imamAddressLng // ignore: cast_nullable_to_non_nullable
                  as double?,
        mohaffezPhone: freezed == mohaffezPhone
            ? _value.mohaffezPhone
            : mohaffezPhone // ignore: cast_nullable_to_non_nullable
                  as String?,
        slotDate: freezed == slotDate
            ? _value.slotDate
            : slotDate // ignore: cast_nullable_to_non_nullable
                  as DateTime?,
        slotStart: freezed == slotStart
            ? _value.slotStart
            : slotStart // ignore: cast_nullable_to_non_nullable
                  as DateTime?,
        slotEnd: freezed == slotEnd
            ? _value.slotEnd
            : slotEnd // ignore: cast_nullable_to_non_nullable
                  as DateTime?,
        createdAt: freezed == createdAt
            ? _value.createdAt
            : createdAt // ignore: cast_nullable_to_non_nullable
                  as DateTime?,
      ),
    );
  }
}

/// @nodoc
@JsonSerializable()
class _$SessionRequestModelImpl implements _SessionRequestModel {
  const _$SessionRequestModelImpl({
    this.id,
    required this.studentId,
    required this.mohaffezId,
    required this.studentName,
    required this.mohaffezName,
    required this.sessionType,
    required this.preferredTimeSlot,
    this.status = SessionRequestStatus.pending,
    this.imamAddressText,
    this.imamAddressLat,
    this.imamAddressLng,
    this.mohaffezPhone,
    @TimestampConverter() this.slotDate,
    @TimestampConverter() this.slotStart,
    @TimestampConverter() this.slotEnd,
    @TimestampConverter() this.createdAt,
  });

  factory _$SessionRequestModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$SessionRequestModelImplFromJson(json);

  @override
  final String? id;
  @override
  final String studentId;
  @override
  final String mohaffezId;
  @override
  final String studentName;
  @override
  final String mohaffezName;
  @override
  final String sessionType;
  @override
  final String preferredTimeSlot;
  @override
  @JsonKey()
  final SessionRequestStatus status;
  @override
  final String? imamAddressText;
  @override
  final double? imamAddressLat;
  @override
  final double? imamAddressLng;
  @override
  final String? mohaffezPhone;
  @override
  @TimestampConverter()
  final DateTime? slotDate;
  @override
  @TimestampConverter()
  final DateTime? slotStart;
  @override
  @TimestampConverter()
  final DateTime? slotEnd;
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'SessionRequestModel(id: $id, studentId: $studentId, mohaffezId: $mohaffezId, studentName: $studentName, mohaffezName: $mohaffezName, sessionType: $sessionType, preferredTimeSlot: $preferredTimeSlot, status: $status, imamAddressText: $imamAddressText, imamAddressLat: $imamAddressLat, imamAddressLng: $imamAddressLng, mohaffezPhone: $mohaffezPhone, slotDate: $slotDate, slotStart: $slotStart, slotEnd: $slotEnd, createdAt: $createdAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SessionRequestModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.studentId, studentId) ||
                other.studentId == studentId) &&
            (identical(other.mohaffezId, mohaffezId) ||
                other.mohaffezId == mohaffezId) &&
            (identical(other.studentName, studentName) ||
                other.studentName == studentName) &&
            (identical(other.mohaffezName, mohaffezName) ||
                other.mohaffezName == mohaffezName) &&
            (identical(other.sessionType, sessionType) ||
                other.sessionType == sessionType) &&
            (identical(other.preferredTimeSlot, preferredTimeSlot) ||
                other.preferredTimeSlot == preferredTimeSlot) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.imamAddressText, imamAddressText) ||
                other.imamAddressText == imamAddressText) &&
            (identical(other.imamAddressLat, imamAddressLat) ||
                other.imamAddressLat == imamAddressLat) &&
            (identical(other.imamAddressLng, imamAddressLng) ||
                other.imamAddressLng == imamAddressLng) &&
            (identical(other.mohaffezPhone, mohaffezPhone) ||
                other.mohaffezPhone == mohaffezPhone) &&
            (identical(other.slotDate, slotDate) ||
                other.slotDate == slotDate) &&
            (identical(other.slotStart, slotStart) ||
                other.slotStart == slotStart) &&
            (identical(other.slotEnd, slotEnd) || other.slotEnd == slotEnd) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
    runtimeType,
    id,
    studentId,
    mohaffezId,
    studentName,
    mohaffezName,
    sessionType,
    preferredTimeSlot,
    status,
    imamAddressText,
    imamAddressLat,
    imamAddressLng,
    mohaffezPhone,
    slotDate,
    slotStart,
    slotEnd,
    createdAt,
  );

  /// Create a copy of SessionRequestModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$SessionRequestModelImplCopyWith<_$SessionRequestModelImpl> get copyWith =>
      __$$SessionRequestModelImplCopyWithImpl<_$SessionRequestModelImpl>(
        this,
        _$identity,
      );

  @override
  Map<String, dynamic> toJson() {
    return _$$SessionRequestModelImplToJson(this);
  }
}

abstract class _SessionRequestModel implements SessionRequestModel {
  const factory _SessionRequestModel({
    final String? id,
    required final String studentId,
    required final String mohaffezId,
    required final String studentName,
    required final String mohaffezName,
    required final String sessionType,
    required final String preferredTimeSlot,
    final SessionRequestStatus status,
    final String? imamAddressText,
    final double? imamAddressLat,
    final double? imamAddressLng,
    final String? mohaffezPhone,
    @TimestampConverter() final DateTime? slotDate,
    @TimestampConverter() final DateTime? slotStart,
    @TimestampConverter() final DateTime? slotEnd,
    @TimestampConverter() final DateTime? createdAt,
  }) = _$SessionRequestModelImpl;

  factory _SessionRequestModel.fromJson(Map<String, dynamic> json) =
      _$SessionRequestModelImpl.fromJson;

  @override
  String? get id;
  @override
  String get studentId;
  @override
  String get mohaffezId;
  @override
  String get studentName;
  @override
  String get mohaffezName;
  @override
  String get sessionType;
  @override
  String get preferredTimeSlot;
  @override
  SessionRequestStatus get status;
  @override
  String? get imamAddressText;
  @override
  double? get imamAddressLat;
  @override
  double? get imamAddressLng;
  @override
  String? get mohaffezPhone;
  @override
  @TimestampConverter()
  DateTime? get slotDate;
  @override
  @TimestampConverter()
  DateTime? get slotStart;
  @override
  @TimestampConverter()
  DateTime? get slotEnd;
  @override
  @TimestampConverter()
  DateTime? get createdAt;

  /// Create a copy of SessionRequestModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$SessionRequestModelImplCopyWith<_$SessionRequestModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
