// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$UserModelImpl _$$UserModelImplFromJson(Map<String, dynamic> json) =>
    _$UserModelImpl(
      uid: json['uid'] as String,
      email: json['email'] as String,
      name: json['name'] as String,
      role: json['role'] as String,
      photoUrl: json['photoUrl'] as String?,
      phone: json['phone'] as String?,
      mobile: json['mobile'] as String?,
      specialization: json['specialization'] as String?,
      addressText: json['addressText'] as String?,
      addressLat: (json['addressLat'] as num?)?.toDouble(),
      addressLng: (json['addressLng'] as num?)?.toDouble(),
      followerCount: (json['followerCount'] as num?)?.toInt() ?? 0,
      followingCount: (json['followingCount'] as num?)?.toInt() ?? 0,
      reviewCount: (json['reviewCount'] as num?)?.toInt() ?? 0,
      rating: (json['rating'] as num?)?.toDouble() ?? 4.5,
      createdAt: const TimestampConverter().fromJson(json['createdAt']),
    );

Map<String, dynamic> _$$UserModelImplToJson(_$UserModelImpl instance) =>
    <String, dynamic>{
      'uid': instance.uid,
      'email': instance.email,
      'name': instance.name,
      'role': instance.role,
      'photoUrl': instance.photoUrl,
      'phone': instance.phone,
      'mobile': instance.mobile,
      'specialization': instance.specialization,
      'addressText': instance.addressText,
      'addressLat': instance.addressLat,
      'addressLng': instance.addressLng,
      'followerCount': instance.followerCount,
      'followingCount': instance.followingCount,
      'reviewCount': instance.reviewCount,
      'rating': instance.rating,
      'createdAt': const TimestampConverter().toJson(instance.createdAt),
    };
