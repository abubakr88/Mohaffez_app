// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'notification_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$NotificationModelImpl _$$NotificationModelImplFromJson(
  Map<String, dynamic> json,
) => _$NotificationModelImpl(
  id: json['id'] as String?,
  userId: json['userId'] as String,
  title: json['title'] as String,
  body: json['body'] as String,
  type: json['type'] as String,
  isRead: json['isRead'] as bool? ?? false,
  scheduleId: json['scheduleId'] as String?,
  mohaffezId: json['mohaffezId'] as String?,
  mohaffezName: json['mohaffezName'] as String?,
  createdAt: const TimestampConverter().fromJson(
    (json['createdAt'] as num?)?.toInt(),
  ),
);

Map<String, dynamic> _$$NotificationModelImplToJson(
  _$NotificationModelImpl instance,
) => <String, dynamic>{
  'id': instance.id,
  'userId': instance.userId,
  'title': instance.title,
  'body': instance.body,
  'type': instance.type,
  'isRead': instance.isRead,
  'scheduleId': instance.scheduleId,
  'mohaffezId': instance.mohaffezId,
  'mohaffezName': instance.mohaffezName,
  'createdAt': const TimestampConverter().toJson(instance.createdAt),
};
