// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'session_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
  'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models',
);

SessionModel _$SessionModelFromJson(Map<String, dynamic> json) {
  return _SessionModel.fromJson(json);
}

/// @nodoc
mixin _$SessionModel {
  String? get id => throw _privateConstructorUsedError;
  String get mohaffezId => throw _privateConstructorUsedError;
  String get studentId => throw _privateConstructorUsedError;
  String get mohaffezName => throw _privateConstructorUsedError;
  String get studentName => throw _privateConstructorUsedError;
  String get sessionType =>
      throw _privateConstructorUsedError; // 'home' or 'mosque'
  String get location => throw _privateConstructorUsedError;
  String? get mohaffezPhone => throw _privateConstructorUsedError;
  double? get imamAddressLat => throw _privateConstructorUsedError;
  double? get imamAddressLng => throw _privateConstructorUsedError;
  String? get preferredTimeSlot => throw _privateConstructorUsedError;
  int get juzCount => throw _privateConstructorUsedError;
  String? get hifzAssignment => throw _privateConstructorUsedError;
  String? get murajaAssignment => throw _privateConstructorUsedError;
  int get sessionRating => throw _privateConstructorUsedError;
  String? get sessionNotes => throw _privateConstructorUsedError;
  @TimestampConverter()
  DateTime? get sessionDate => throw _privateConstructorUsedError;
  @TimestampConverter()
  DateTime? get slotStart => throw _privateConstructorUsedError;
  @TimestampConverter()
  DateTime? get slotEnd => throw _privateConstructorUsedError;
  @TimestampConverter()
  DateTime? get createdAt => throw _privateConstructorUsedError;

  /// Serializes this SessionModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of SessionModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $SessionModelCopyWith<SessionModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SessionModelCopyWith<$Res> {
  factory $SessionModelCopyWith(
    SessionModel value,
    $Res Function(SessionModel) then,
  ) = _$SessionModelCopyWithImpl<$Res, SessionModel>;
  @useResult
  $Res call({
    String? id,
    String mohaffezId,
    String studentId,
    String mohaffezName,
    String studentName,
    String sessionType,
    String location,
    String? mohaffezPhone,
    double? imamAddressLat,
    double? imamAddressLng,
    String? preferredTimeSlot,
    int juzCount,
    String? hifzAssignment,
    String? murajaAssignment,
    int sessionRating,
    String? sessionNotes,
    @TimestampConverter() DateTime? sessionDate,
    @TimestampConverter() DateTime? slotStart,
    @TimestampConverter() DateTime? slotEnd,
    @TimestampConverter() DateTime? createdAt,
  });
}

/// @nodoc
class _$SessionModelCopyWithImpl<$Res, $Val extends SessionModel>
    implements $SessionModelCopyWith<$Res> {
  _$SessionModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of SessionModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? mohaffezId = null,
    Object? studentId = null,
    Object? mohaffezName = null,
    Object? studentName = null,
    Object? sessionType = null,
    Object? location = null,
    Object? mohaffezPhone = freezed,
    Object? imamAddressLat = freezed,
    Object? imamAddressLng = freezed,
    Object? preferredTimeSlot = freezed,
    Object? juzCount = null,
    Object? hifzAssignment = freezed,
    Object? murajaAssignment = freezed,
    Object? sessionRating = null,
    Object? sessionNotes = freezed,
    Object? sessionDate = freezed,
    Object? slotStart = freezed,
    Object? slotEnd = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(
      _value.copyWith(
            id: freezed == id
                ? _value.id
                : id // ignore: cast_nullable_to_non_nullable
                      as String?,
            mohaffezId: null == mohaffezId
                ? _value.mohaffezId
                : mohaffezId // ignore: cast_nullable_to_non_nullable
                      as String,
            studentId: null == studentId
                ? _value.studentId
                : studentId // ignore: cast_nullable_to_non_nullable
                      as String,
            mohaffezName: null == mohaffezName
                ? _value.mohaffezName
                : mohaffezName // ignore: cast_nullable_to_non_nullable
                      as String,
            studentName: null == studentName
                ? _value.studentName
                : studentName // ignore: cast_nullable_to_non_nullable
                      as String,
            sessionType: null == sessionType
                ? _value.sessionType
                : sessionType // ignore: cast_nullable_to_non_nullable
                      as String,
            location: null == location
                ? _value.location
                : location // ignore: cast_nullable_to_non_nullable
                      as String,
            mohaffezPhone: freezed == mohaffezPhone
                ? _value.mohaffezPhone
                : mohaffezPhone // ignore: cast_nullable_to_non_nullable
                      as String?,
            imamAddressLat: freezed == imamAddressLat
                ? _value.imamAddressLat
                : imamAddressLat // ignore: cast_nullable_to_non_nullable
                      as double?,
            imamAddressLng: freezed == imamAddressLng
                ? _value.imamAddressLng
                : imamAddressLng // ignore: cast_nullable_to_non_nullable
                      as double?,
            preferredTimeSlot: freezed == preferredTimeSlot
                ? _value.preferredTimeSlot
                : preferredTimeSlot // ignore: cast_nullable_to_non_nullable
                      as String?,
            juzCount: null == juzCount
                ? _value.juzCount
                : juzCount // ignore: cast_nullable_to_non_nullable
                      as int,
            hifzAssignment: freezed == hifzAssignment
                ? _value.hifzAssignment
                : hifzAssignment // ignore: cast_nullable_to_non_nullable
                      as String?,
            murajaAssignment: freezed == murajaAssignment
                ? _value.murajaAssignment
                : murajaAssignment // ignore: cast_nullable_to_non_nullable
                      as String?,
            sessionRating: null == sessionRating
                ? _value.sessionRating
                : sessionRating // ignore: cast_nullable_to_non_nullable
                      as int,
            sessionNotes: freezed == sessionNotes
                ? _value.sessionNotes
                : sessionNotes // ignore: cast_nullable_to_non_nullable
                      as String?,
            sessionDate: freezed == sessionDate
                ? _value.sessionDate
                : sessionDate // ignore: cast_nullable_to_non_nullable
                      as DateTime?,
            slotStart: freezed == slotStart
                ? _value.slotStart
                : slotStart // ignore: cast_nullable_to_non_nullable
                      as DateTime?,
            slotEnd: freezed == slotEnd
                ? _value.slotEnd
                : slotEnd // ignore: cast_nullable_to_non_nullable
                      as DateTime?,
            createdAt: freezed == createdAt
                ? _value.createdAt
                : createdAt // ignore: cast_nullable_to_non_nullable
                      as DateTime?,
          )
          as $Val,
    );
  }
}

/// @nodoc
abstract class _$$SessionModelImplCopyWith<$Res>
    implements $SessionModelCopyWith<$Res> {
  factory _$$SessionModelImplCopyWith(
    _$SessionModelImpl value,
    $Res Function(_$SessionModelImpl) then,
  ) = __$$SessionModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({
    String? id,
    String mohaffezId,
    String studentId,
    String mohaffezName,
    String studentName,
    String sessionType,
    String location,
    String? mohaffezPhone,
    double? imamAddressLat,
    double? imamAddressLng,
    String? preferredTimeSlot,
    int juzCount,
    String? hifzAssignment,
    String? murajaAssignment,
    int sessionRating,
    String? sessionNotes,
    @TimestampConverter() DateTime? sessionDate,
    @TimestampConverter() DateTime? slotStart,
    @TimestampConverter() DateTime? slotEnd,
    @TimestampConverter() DateTime? createdAt,
  });
}

/// @nodoc
class __$$SessionModelImplCopyWithImpl<$Res>
    extends _$SessionModelCopyWithImpl<$Res, _$SessionModelImpl>
    implements _$$SessionModelImplCopyWith<$Res> {
  __$$SessionModelImplCopyWithImpl(
    _$SessionModelImpl _value,
    $Res Function(_$SessionModelImpl) _then,
  ) : super(_value, _then);

  /// Create a copy of SessionModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? mohaffezId = null,
    Object? studentId = null,
    Object? mohaffezName = null,
    Object? studentName = null,
    Object? sessionType = null,
    Object? location = null,
    Object? mohaffezPhone = freezed,
    Object? imamAddressLat = freezed,
    Object? imamAddressLng = freezed,
    Object? preferredTimeSlot = freezed,
    Object? juzCount = null,
    Object? hifzAssignment = freezed,
    Object? murajaAssignment = freezed,
    Object? sessionRating = null,
    Object? sessionNotes = freezed,
    Object? sessionDate = freezed,
    Object? slotStart = freezed,
    Object? slotEnd = freezed,
    Object? createdAt = freezed,
  }) {
    return _then(
      _$SessionModelImpl(
        id: freezed == id
            ? _value.id
            : id // ignore: cast_nullable_to_non_nullable
                  as String?,
        mohaffezId: null == mohaffezId
            ? _value.mohaffezId
            : mohaffezId // ignore: cast_nullable_to_non_nullable
                  as String,
        studentId: null == studentId
            ? _value.studentId
            : studentId // ignore: cast_nullable_to_non_nullable
                  as String,
        mohaffezName: null == mohaffezName
            ? _value.mohaffezName
            : mohaffezName // ignore: cast_nullable_to_non_nullable
                  as String,
        studentName: null == studentName
            ? _value.studentName
            : studentName // ignore: cast_nullable_to_non_nullable
                  as String,
        sessionType: null == sessionType
            ? _value.sessionType
            : sessionType // ignore: cast_nullable_to_non_nullable
                  as String,
        location: null == location
            ? _value.location
            : location // ignore: cast_nullable_to_non_nullable
                  as String,
        mohaffezPhone: freezed == mohaffezPhone
            ? _value.mohaffezPhone
            : mohaffezPhone // ignore: cast_nullable_to_non_nullable
                  as String?,
        imamAddressLat: freezed == imamAddressLat
            ? _value.imamAddressLat
            : imamAddressLat // ignore: cast_nullable_to_non_nullable
                  as double?,
        imamAddressLng: freezed == imamAddressLng
            ? _value.imamAddressLng
            : imamAddressLng // ignore: cast_nullable_to_non_nullable
                  as double?,
        preferredTimeSlot: freezed == preferredTimeSlot
            ? _value.preferredTimeSlot
            : preferredTimeSlot // ignore: cast_nullable_to_non_nullable
                  as String?,
        juzCount: null == juzCount
            ? _value.juzCount
            : juzCount // ignore: cast_nullable_to_non_nullable
                  as int,
        hifzAssignment: freezed == hifzAssignment
            ? _value.hifzAssignment
            : hifzAssignment // ignore: cast_nullable_to_non_nullable
                  as String?,
        murajaAssignment: freezed == murajaAssignment
            ? _value.murajaAssignment
            : murajaAssignment // ignore: cast_nullable_to_non_nullable
                  as String?,
        sessionRating: null == sessionRating
            ? _value.sessionRating
            : sessionRating // ignore: cast_nullable_to_non_nullable
                  as int,
        sessionNotes: freezed == sessionNotes
            ? _value.sessionNotes
            : sessionNotes // ignore: cast_nullable_to_non_nullable
                  as String?,
        sessionDate: freezed == sessionDate
            ? _value.sessionDate
            : sessionDate // ignore: cast_nullable_to_non_nullable
                  as DateTime?,
        slotStart: freezed == slotStart
            ? _value.slotStart
            : slotStart // ignore: cast_nullable_to_non_nullable
                  as DateTime?,
        slotEnd: freezed == slotEnd
            ? _value.slotEnd
            : slotEnd // ignore: cast_nullable_to_non_nullable
                  as DateTime?,
        createdAt: freezed == createdAt
            ? _value.createdAt
            : createdAt // ignore: cast_nullable_to_non_nullable
                  as DateTime?,
      ),
    );
  }
}

/// @nodoc
@JsonSerializable()
class _$SessionModelImpl implements _SessionModel {
  const _$SessionModelImpl({
    this.id,
    required this.mohaffezId,
    required this.studentId,
    required this.mohaffezName,
    required this.studentName,
    required this.sessionType,
    required this.location,
    this.mohaffezPhone,
    this.imamAddressLat,
    this.imamAddressLng,
    this.preferredTimeSlot,
    this.juzCount = 1,
    this.hifzAssignment,
    this.murajaAssignment,
    this.sessionRating = 0,
    this.sessionNotes,
    @TimestampConverter() this.sessionDate,
    @TimestampConverter() this.slotStart,
    @TimestampConverter() this.slotEnd,
    @TimestampConverter() this.createdAt,
  });

  factory _$SessionModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$SessionModelImplFromJson(json);

  @override
  final String? id;
  @override
  final String mohaffezId;
  @override
  final String studentId;
  @override
  final String mohaffezName;
  @override
  final String studentName;
  @override
  final String sessionType;
  // 'home' or 'mosque'
  @override
  final String location;
  @override
  final String? mohaffezPhone;
  @override
  final double? imamAddressLat;
  @override
  final double? imamAddressLng;
  @override
  final String? preferredTimeSlot;
  @override
  @JsonKey()
  final int juzCount;
  @override
  final String? hifzAssignment;
  @override
  final String? murajaAssignment;
  @override
  @JsonKey()
  final int sessionRating;
  @override
  final String? sessionNotes;
  @override
  @TimestampConverter()
  final DateTime? sessionDate;
  @override
  @TimestampConverter()
  final DateTime? slotStart;
  @override
  @TimestampConverter()
  final DateTime? slotEnd;
  @override
  @TimestampConverter()
  final DateTime? createdAt;

  @override
  String toString() {
    return 'SessionModel(id: $id, mohaffezId: $mohaffezId, studentId: $studentId, mohaffezName: $mohaffezName, studentName: $studentName, sessionType: $sessionType, location: $location, mohaffezPhone: $mohaffezPhone, imamAddressLat: $imamAddressLat, imamAddressLng: $imamAddressLng, preferredTimeSlot: $preferredTimeSlot, juzCount: $juzCount, hifzAssignment: $hifzAssignment, murajaAssignment: $murajaAssignment, sessionRating: $sessionRating, sessionNotes: $sessionNotes, sessionDate: $sessionDate, slotStart: $slotStart, slotEnd: $slotEnd, createdAt: $createdAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SessionModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.mohaffezId, mohaffezId) ||
                other.mohaffezId == mohaffezId) &&
            (identical(other.studentId, studentId) ||
                other.studentId == studentId) &&
            (identical(other.mohaffezName, mohaffezName) ||
                other.mohaffezName == mohaffezName) &&
            (identical(other.studentName, studentName) ||
                other.studentName == studentName) &&
            (identical(other.sessionType, sessionType) ||
                other.sessionType == sessionType) &&
            (identical(other.location, location) ||
                other.location == location) &&
            (identical(other.mohaffezPhone, mohaffezPhone) ||
                other.mohaffezPhone == mohaffezPhone) &&
            (identical(other.imamAddressLat, imamAddressLat) ||
                other.imamAddressLat == imamAddressLat) &&
            (identical(other.imamAddressLng, imamAddressLng) ||
                other.imamAddressLng == imamAddressLng) &&
            (identical(other.preferredTimeSlot, preferredTimeSlot) ||
                other.preferredTimeSlot == preferredTimeSlot) &&
            (identical(other.juzCount, juzCount) ||
                other.juzCount == juzCount) &&
            (identical(other.hifzAssignment, hifzAssignment) ||
                other.hifzAssignment == hifzAssignment) &&
            (identical(other.murajaAssignment, murajaAssignment) ||
                other.murajaAssignment == murajaAssignment) &&
            (identical(other.sessionRating, sessionRating) ||
                other.sessionRating == sessionRating) &&
            (identical(other.sessionNotes, sessionNotes) ||
                other.sessionNotes == sessionNotes) &&
            (identical(other.sessionDate, sessionDate) ||
                other.sessionDate == sessionDate) &&
            (identical(other.slotStart, slotStart) ||
                other.slotStart == slotStart) &&
            (identical(other.slotEnd, slotEnd) || other.slotEnd == slotEnd) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hashAll([
    runtimeType,
    id,
    mohaffezId,
    studentId,
    mohaffezName,
    studentName,
    sessionType,
    location,
    mohaffezPhone,
    imamAddressLat,
    imamAddressLng,
    preferredTimeSlot,
    juzCount,
    hifzAssignment,
    murajaAssignment,
    sessionRating,
    sessionNotes,
    sessionDate,
    slotStart,
    slotEnd,
    createdAt,
  ]);

  /// Create a copy of SessionModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$SessionModelImplCopyWith<_$SessionModelImpl> get copyWith =>
      __$$SessionModelImplCopyWithImpl<_$SessionModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SessionModelImplToJson(this);
  }
}

abstract class _SessionModel implements SessionModel {
  const factory _SessionModel({
    final String? id,
    required final String mohaffezId,
    required final String studentId,
    required final String mohaffezName,
    required final String studentName,
    required final String sessionType,
    required final String location,
    final String? mohaffezPhone,
    final double? imamAddressLat,
    final double? imamAddressLng,
    final String? preferredTimeSlot,
    final int juzCount,
    final String? hifzAssignment,
    final String? murajaAssignment,
    final int sessionRating,
    final String? sessionNotes,
    @TimestampConverter() final DateTime? sessionDate,
    @TimestampConverter() final DateTime? slotStart,
    @TimestampConverter() final DateTime? slotEnd,
    @TimestampConverter() final DateTime? createdAt,
  }) = _$SessionModelImpl;

  factory _SessionModel.fromJson(Map<String, dynamic> json) =
      _$SessionModelImpl.fromJson;

  @override
  String? get id;
  @override
  String get mohaffezId;
  @override
  String get studentId;
  @override
  String get mohaffezName;
  @override
  String get studentName;
  @override
  String get sessionType; // 'home' or 'mosque'
  @override
  String get location;
  @override
  String? get mohaffezPhone;
  @override
  double? get imamAddressLat;
  @override
  double? get imamAddressLng;
  @override
  String? get preferredTimeSlot;
  @override
  int get juzCount;
  @override
  String? get hifzAssignment;
  @override
  String? get murajaAssignment;
  @override
  int get sessionRating;
  @override
  String? get sessionNotes;
  @override
  @TimestampConverter()
  DateTime? get sessionDate;
  @override
  @TimestampConverter()
  DateTime? get slotStart;
  @override
  @TimestampConverter()
  DateTime? get slotEnd;
  @override
  @TimestampConverter()
  DateTime? get createdAt;

  /// Create a copy of SessionModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$SessionModelImplCopyWith<_$SessionModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
